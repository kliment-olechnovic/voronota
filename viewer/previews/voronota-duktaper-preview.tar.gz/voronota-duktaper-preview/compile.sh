#!/bin/bash

cd "$(dirname "$0")"

g++ -std=c++14 -I"./src/duktaper/src/dependencies" -O3 -o "./voronota-duktaper" \
  "./src/duktaper/src/dependencies/tmalign/TMalign.cpp" \
  "./src/duktaper/src/dependencies/duktape/duktape.cpp" \
  "./src/duktaper/src/voronota_duktaper.cpp"
