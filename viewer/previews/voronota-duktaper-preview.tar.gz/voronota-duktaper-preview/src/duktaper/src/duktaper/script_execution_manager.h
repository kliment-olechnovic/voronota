#ifndef DUKTAPER_SCRIPT_EXECUTION_MANAGER_H_
#define DUKTAPER_SCRIPT_EXECUTION_MANAGER_H_

#include "../../../src/scripting/script_execution_manager_with_variant_output.h"

#include "operators_all.h"

namespace voronota
{

namespace duktaper
{

class ScriptExecutionManager : public scripting::ScriptExecutionManagerWithVariantOutput
{
public:
	ScriptExecutionManager()
	{
		set_command_for_extra_actions("call-shell", operators::CallShell());
		set_command_for_extra_actions("checksum", operators::Checksum());
		set_command_for_extra_actions("nnport-predict", operators::NNPortPredict());
		set_command_for_extra_actions("setup-defaults", operators::SetupDefaults());
		set_command_for_extra_actions("tournament-sort", operators::TournamentSort());

		set_command_for_data_manager("construct-or-load-contacts", operators::ConstructOrLoadContacts(), true);
		set_command_for_data_manager("construct-or-load-quality-scores", operators::ConstructOrLoadQualityScores(), true);
		set_command_for_data_manager("scwrl", operators::Scwrl(), true);
		set_command_for_data_manager("voromqa-dark-global", operators::VoroMQADarkGlobal(), true);
		set_command_for_data_manager("voromqa-dark-local", operators::VoroMQADarkLocal(), true);
		set_command_for_data_manager("voromqa-dark-split", operators::VoroMQADarkSplit(), true);

		set_command_for_congregation_of_data_managers("fetch", operators::Fetch());
		set_command_for_congregation_of_data_managers("tmalign-many", operators::TMalignMany());
		set_command_for_congregation_of_data_managers("tmalign", operators::TMalign());
	}
};

}

}

#endif /* DUKTAPER_SCRIPT_EXECUTION_MANAGER_H_ */
