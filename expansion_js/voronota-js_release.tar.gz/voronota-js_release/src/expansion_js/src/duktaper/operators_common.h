#ifndef DUKTAPER_OPERATORS_COMMON_H_
#define DUKTAPER_OPERATORS_COMMON_H_

#include "../../../src/scripting/operators_common.h"

#endif /* DUKTAPER_OPERATORS_COMMON_H_ */
